# Codex Personal Skills Backup

Personal backup of Codex skills for reuse across computers.

## Inventory

| Skill | Purpose | Source |
|---|---|---|
| `academic-research-suite` | Academic research, writing, review, and experiment workflows | https://github.com/Imbad0202/academic-research-skills-codex |
| `research-clarifier` | Clarify complex research problems before proposing solutions | Locally authored personal skill |
| `bilingual-humanizer` | Humanize Chinese, English, or mixed-language prose while preserving claims and citations | Local ZIP package |

Total personal skills in this backup: **3**.

## Restore

Copy the desired folder from `skills/` into the target computer's Codex user skill directory:

```text
$CODEX_HOME/skills/<skill-name>
```

When `CODEX_HOME` is unset, use the user-level Codex skills directory configured on that computer. Open a new Codex conversation after restoring so the skill list refreshes.

## Update this backup

Replace the corresponding folder under `skills/`, update `skills.json`, commit, and push. Keep each skill directory self-contained, including its `SKILL.md`, `agents/`, references, assets, scripts, and license files.

## Notes

- This repository is intended as a backup and inventory, not as a single combined skill.
- Preserve upstream license and attribution files.
- Review private or sensitive reference materials before making the repository public.
