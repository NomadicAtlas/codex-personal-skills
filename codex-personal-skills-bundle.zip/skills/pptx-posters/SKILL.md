---
name: pptx-posters
description: Create and audit editable scientific conference and research posters in macro-free PowerPoint (.pptx) from local content and assets, with separate draft, content-final, and print-release workflows. Use when the requested deliverable is a PowerPoint scientific poster requiring exact physical dimensions, printer checks, accessibility, provenance, manifest validation, and package-security review.
---


# PPTX posters

## Scope

Use this skill only when the requested source/deliverable is an editable PowerPoint
poster. Do not route an unspecified poster request here merely because PowerPoint is
available.

Version 2.0 generates a real one-slide `.pptx` from strict local JSON. It does not use
HTML conversion, external templates, schematic/image-generation services, API keys,
environment files, network requests, or mandatory figure styles.

## Select the delivery stage first

Default to **draft** for a request to make an initial poster or try layouts. Use `scripts/generate_review_poster.py` with the lightweight review schema described in `references/review_workflow.md`. It produces a real editable PPTX with a visible review status and a report of pending issues. Supplied content may be summarized within the user's authorized scope; mark missing facts and source checks explicitly rather than inventing them. Do not require printer confirmation, complete final content, or a hash approval to begin a draft.

Use **content-final** only when the author actually confirmed the scientific text, names, claims, figures, and citations. The review generator requires a recorded reviewer, no pending content, and sources for all elements. Layout-only edits within the authorized task do not require renewed content approval; the report records the input/output hashes for traceability. Any changed scientific proposition, number, quotation, source attribution, or author detail needs content review again. Never invent a reviewer, approval, or source record.

Use **print release** only when requested or preparing final production. The original strict 2.0 manifest/generator and checks below remain unchanged and apply to this stage. Bind the final production approval to the final manifest, including layout. Never convert a draft into an approved release by filling confirmation booleans yourself. Drafts and content-final files are not certified for submission or print.

Inspect the chosen runtime before installing packages. The review generator records actual versions; the strict release generator still requires its exact pins in an isolated environment. Do not mutate global dependencies.

## Print-release hard gates

For the strict print-release path, stop that release step instead of guessing when any gate is unmet. Continue useful draft or content-review work when authorized:

1. The author has not supplied exact poster content and source records.
2. Any claim, number, citation, author, affiliation, funding statement, figure,
   license, or QR target is unresolved.
3. Current conference and printer requirements are not confirmed.
4. Author approval is not bound to the current manifest content hash.
5. An asset is remote, outside the manifest directory, unhashed, or unapproved.
6. An input is `.pptm`, contains macros/external relationships/OLE/embedded files,
   or is an untrusted template.
7. The requested workflow needs PowerPoint to be opened or executed automatically.
8. A script reports a package, layout, DPI, contrast, or output-plan blocker.

Never fabricate missing material. Explicit pending labels are allowed in drafts and must not be passed to the strict release generator as verified content.

## Install exact print-release generation dependencies

From the skill directory:

```bash
uv venv
uv pip install "python-pptx==1.0.2" "Pillow==12.3.0" "lxml==6.1.1"
```

Generation requires exactly:

```text
python-pptx==1.0.2
Pillow==12.3.0
lxml==6.1.1
```

All CLIs use lazy optional imports, so `python -B scripts/<tool>.py --help` works
without these packages. Use `-B` to avoid bytecode artifacts.

## Establish requirements before layout

Record these separately:

- physical trim width/height and orientation;
- bleed on each edge;
- safe margin inside trim;
- PowerPoint canvas width/height;
- uniform physical-artboard/canvas print scale;
- conference maximum dimensions and delivery format;
- printer trim, bleed, margin, scaling, color-mode, and proof requirements;
- final-output font and raster-DPI thresholds, each labeled as a heuristic or tied to
  an exact source.
- required font faces, workstation availability, embedding permission, and the
  substitution/proof workflow.

There is no universal poster size. Microsoft currently limits each custom PowerPoint
dimension to 1–56 inches and uses one size for all slides. If the physical artboard
is larger, use a proportional canvas only when the printer confirms scaling.

Read `references/poster_layout_design.md`.

## Build the manifest

Copy `assets/poster_manifest_template.json` into the project. The template is
deliberately invalid until every replacement token, false confirmation, and draft
approval is resolved.

Follow `references/manifest_spec.md` and `references/poster_content_guide.md`.

The manifest requires:

- exact source IDs for document metadata, every element, and every asset;
- `author_verified: true` on every source;
- `author_approved: true` on every element and asset;
- local PNG/JPEG paths and lowercase SHA-256 hashes;
- exact provenance and license/permission for every optional image;
- approved alt text and, when needed, a source-bound native long description;
- explicit reading order and design rectangles;
- visible exact fallback URL/text for every local QR image;
- confirmed conference/printer rules;
- declared sRGB contrast pairs and redundant data encoding;
- approval bound to canonical manifest content.

To obtain the content hash after all non-approval fields pass:

```bash
python -B scripts/validate_manifest.py poster.json \
  --print-content-hash
```

Give that exact manifest and hash to the author. Then set `approval.status` to
`approved`, record approver and offset-aware timestamp, and copy the hash. Any
non-approval edit invalidates approval.

Validate the approved manifest and local assets:

```bash
python -B scripts/validate_manifest.py poster.json
```

## Audit assets and palette before generation

```bash
python -B scripts/inventory_images.py poster.json \
  --output poster.assets.json

python -B scripts/check_palette.py poster.json \
  --output poster.palette.json

python -B scripts/plan_export.py poster.json \
  --output poster.export-plan.json
```

Effective DPI is pixels divided by final placed inches, not image metadata DPI.
The inventory fully decodes bounded images and blocks EXIF/XMP/comments and embedded
text/application metadata;
strip those offline, then rehash and reapprove the asset.
Contrast uses WCAG 2.2 sRGB mathematics; applying those values to a physical poster is
a design target, not a standalone conformance claim. Keep color-redundant labels,
markers, shapes, patterns, or line styles.

If the printer requires CMYK, the plan blocks print-readiness until a
printer-approved conversion/profile and proof exist. Do not claim that a native
PowerPoint PDF is CMYK-compliant.

Read `references/poster_design_principles.md`.

## Generate the PPTX

Use a new output path:

```bash
python -B scripts/generate_poster.py poster.json \
  --output poster.pptx \
  --report poster.generation.json
```

Generation:

- creates a new blank presentation; it never loads a user template;
- sets the approved canvas before adding content;
- uses one native title placeholder, native text boxes, and local pictures;
- preserves image aspect ratio with `contain` fitting;
- disables text auto-shrink;
- adds elements in approved reading order;
- writes approved picture alt descriptions and explicit text language to PresentationML;
- does not embed fonts, audio, video, OLE, ActiveX, links, or other media;
- removes default printer-settings binary data and normalizes package timestamps;
- inspects the package before and after the alt-text patch;
- refuses overlaps, out-of-bounds shapes, low final font size/DPI, unsafe packages,
  and existing destinations.

It renders exact manifest text. It does not compose, summarize, research, or correct
scientific content.

## Run final technical audits

```bash
python -B scripts/inspect_pptx.py poster.pptx \
  --output poster.package.json

python -B scripts/check_layout.py poster.pptx \
  --manifest poster.json \
  --output poster.layout.json
```

The package inspector reads bounded ZIP metadata and selected XML only. It never
extracts members or opens/executes the presentation. It rejects:

- every non-`.pptx` extension, including `.pptm`;
- packages outside the bounded one-slide generator profile;
- macro/VBA, ActiveX, custom UI, OLE, embedded, executable, and binary parts;
- every external relationship, including remote linked images and hyperlinks;
- unsafe/duplicate ZIP paths, symlinks, encryption, oversized expansion, and
  excessive compression ratios;
- malformed or entity-bearing inspected XML;
- missing internal relationship targets.

Read `references/pptx_security.md`.

## Manual PowerPoint and accessibility gate

Automation cannot certify accessibility, text rendering, or scientific accuracy.
In a fully patched PowerPoint:

1. Open only the generated and technically clean file.
2. Run Review > Check Accessibility.
3. Inspect the Reading Order pane and object names.
4. Review every alt text and native long description.
5. Test keyboard and screen-reader navigation.
6. Confirm fonts are installed/licensed; check embedding choices, substitution, glyphs,
   equations, overflow, contrast, and all edges.
7. Verify that color is never the only encoding.
8. Test every QR code and its visible fallback URL/text.
9. Obtain author sign-off on all content and citations.

Microsoft's 18 pt slide recommendation is not a universal poster minimum. Evaluate
font size at final physical output using the manifest's labeled basis and proofs.

## Export and print

Use the approved export plan. When PDF is required, export from the reviewed
PowerPoint using Standard/high print quality rather than Minimum size.

Independently verify the PDF:

- page/artboard dimensions, orientation, trim, and bleed;
- one-page output if required;
- fonts, clipping, glyphs, equations, and image resampling;
- tags, reading order, alt text, language, and links;
- RGB/CMYK conversion and physical color proof;
- conference naming, file-size, and upload rules.

Print a reduced-scale proof and obtain the printer's required proof. Re-run all checks
after any change.

Use `assets/poster_quality_checklist.md` for release sign-off.

## Bundled CLIs

- `generate_review_poster.py` — draft/content-final PPTX with visible status, pending-item report, local hashed images, and package inspection; never claims print readiness.


- `validate_manifest.py` — strict content/provenance/approval validator.
- `generate_poster.py` — exact-pinned local PPTX generator.
- `inspect_pptx.py` — non-executing ZIP/XML security inspector.
- `check_layout.py` — bounds, overlap, reading-order, and final-font checker.
- `inventory_images.py` — asset hash/metadata/effective-DPI manifest.
- `check_palette.py` — WCAG contrast and heuristic palette report.
- `plan_export.py` — dimensions, scale, fonts, color, media, export, and print preflight.

## References

- `references/manifest_spec.md`
- `references/poster_content_guide.md`
- `references/poster_design_principles.md`
- `references/poster_layout_design.md`
- `references/pptx_security.md`
- `references/security_validation.md`
- `references/source_ledger.md`
