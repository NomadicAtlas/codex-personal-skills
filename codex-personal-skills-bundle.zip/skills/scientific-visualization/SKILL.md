---
name: scientific-visualization
description: Create and audit truthful, accessible, publication-ready scientific figures with Matplotlib, Seaborn, or Plotly. Use for scientific figure design, multi-panel layouts, uncertainty and missing-data displays, color and contrast review, image metadata validation, and journal export planning.
---


# Scientific Visualization

Build figures that preserve scientific meaning before optimizing appearance. Separate universal principles from dated publisher rules, preserve raw data and transformations, use color redundantly, and inspect delivered files rather than trusting plotting defaults.

## Non-negotiable guardrails

- Never alter, hide, invent, or selectively enhance data to improve a figure.
- Preserve raw tables/images, exclusions, missing-value codes, analysis code, normalization, binning, image adjustments, and random seeds.
- Do not infer journal requirements. For a journal-targeted deliverable, identify the exact journal, article type, figure type, and submission phase and verify applicable official guidance. A general or exploratory figure does not require a target journal.
- Do not claim that a palette, DPI value, format, or automated report makes a figure accessible or journal-compliant.
- Do not silently connect missing observations, suppress inconvenient points, upsample images as if detail increased, or tune axes/dual axes to exaggerate a conclusion.
- Keep interactive and static outputs as distinct deliverables. Interactive hover is not a substitute for labels, alt text, keyboard access, an accessible data table, or a static fallback.

Read `references/publication_guidelines.md` for deceptive-encoding and integrity checks. Read `references/journal_requirements.md` only after the target and phase are known.

## Workflow

### 1. Define the evidence and destination

Distinguish an exploratory/general figure from a journal-targeted or final-submission deliverable. Proceed with reasonable labeled design defaults for exploratory work; do not ask for a journal or printer merely to begin. Apply evidence integrity, clear labels and scales, and exported-output inspection in every mode. Add journal, print, or interactive checks only when relevant to the requested destination.

Record:

- audience and medium: manuscript, web, slide, poster, supplement;
- exact publisher/journal, article type, submission phase, and intended final width;
- variable semantics, units, sample/replicate structure, missing/censored values;
- estimator and uncertainty definition;
- transformations: filtering, aggregation, normalization, smoothing, bins, image processing;
- source-data paths/identifiers and output provenance.

If requirements are not known, create a provisional general figure and label all publisher choices as pending verification.

### 2. Choose an honest encoding

Prefer position on a common scale. Before coding, check:

- **Bars/areas:** normally include zero because length/area is measured from a baseline.
- **Points/lines:** nonzero limits can be valid; show context and disclose breaks.
- **Uncertainty:** name SD, SE, CI, percentile, posterior, or another interval; state `n` and the unit of replication.
- **Raw observations:** show them when feasible; do not let jitter obscure categories/values.
- **Missing data:** distinguish missing, zero, censored, and excluded; use gaps or explicit model/interpolation styling.
- **Area/volume:** scale area/volume, not radius/diameter; avoid decorative 3D.
- **Log axes:** label the base/transform and declare how zero/negative values are handled.
- **Binning/smoothing:** record edges, bandwidth/window, method, and sensitivity.
- **Normalization:** state formula/reference and keep limits consistent across compared panels.
- **Dual axes:** prefer aligned panels; if unavoidable, justify units and do not engineer apparent correlation.
- **Images:** preserve originals, disclose whole-image adjustments, show scale bars, and avoid clipped/erased background.

### 3. Design accessibility in, not after

- Use color plus marker, line style, hatching, direct label, or panel separation.
- Choose qualitative, sequential, diverging, or cyclic color according to data semantics.
- Audit foreground/background contrast at the rendered size.
- Make missing and out-of-range values explicit.
- Provide alt text, a longer description for complex figures, and underlying data for web delivery.
- Treat WCAG 2.2 as web guidance: 4.5:1 normal text, 3:1 large text, and 3:1 for graphical objects required for understanding; color cannot be the only cue. Applicability and exceptions matter.

See `references/color_palettes.md`. A grayscale screen is useful but is not a complete color-vision or accessibility test.

### 4. Implement with scoped styles

Use Matplotlib's object-oriented API and temporary style contexts:

```python
import matplotlib.pyplot as plt

from style_presets import style_context

with style_context("default", palette_name="okabe_ito_on_white"):
    fig, ax = plt.subplots(
        figsize=(89 / 25.4, 60 / 25.4),
        layout="constrained",
    )
    ax.plot(x, y, marker="o", label="Observed")
    ax.set(xlabel="Time (hours)", ylabel="Response (unit)")
    ax.legend()
```

`layout="constrained"` supports colorbars, nested GridSpec, subfigures, and `subplot_mosaic`. Do not call `tight_layout()` afterward; it disables constrained layout.

For exact physical dimensions, do not use `bbox_inches="tight"` unless the changed page size is intentional.

#### Color normalization

```python
import matplotlib as mpl

norm = mpl.colors.TwoSlopeNorm(vmin=-2, vcenter=0, vmax=5)
cmap = mpl.colormaps["RdBu_r"].with_extremes(bad="#777777")
image = ax.imshow(values, norm=norm, cmap=cmap, interpolation="nearest")
fig.colorbar(image, ax=ax, label="Change (unit)")
```

Use `LogNorm`, `CenteredNorm`, `SymLogNorm`, `BoundaryNorm`, or `TwoSlopeNorm` only when its mapping matches the scientific meaning.

#### Seaborn

Seaborn 0.13.2 uses the current `errorbar` API:

```python
sns.lineplot(
    data=frame,
    x="time",
    y="response",
    hue="treatment",
    style="treatment",
    markers=True,
    errorbar=("ci", 95),
    n_boot=5000,
    seed=20260723,
    ax=ax,
)
```

Axes-level functions fit custom Matplotlib layouts; figure-level functions create their own figures/facets. Do not customize Seaborn's internal artist lists as if they were stable API.

#### Plotly

- Use `write_html()` for interaction and `write_image()`/`plotly.io.write_images()` for static output.
- Kaleido 1.3.0 requires Chrome/Chromium; it no longer bundles Chrome.
- Current static formats: PNG, JPEG, WebP, SVG, PDF. EPS is Kaleido v0-only.
- Do not pass deprecated `engine=` or use Orca/`plotly.io.kaleido.scope`.
- `width`, `height`, and `scale` control pixels; `scale=3` is not inherently “300 DPI.”
- WebGL traces embed raster content in PDF/SVG.
- Fully offline exports need local external assets when a figure references MathJax/topojson/tiles.

### 5. Export explicitly and record provenance

```python
from figure_export import export_figure

report = export_figure(
    fig,
    "outputs/figure1",
    formats=["pdf", "png"],
    dpi=600,
    bbox_inches=None,  # preserve figure page dimensions
    provenance={
        "raw_data": "data/source.csv",
        "transformations": ["predeclared QC filter", "group mean"],
        "uncertainty": "95% bootstrap CI; seed 20260723",
        "missing_data": "retained as gaps",
    },
    write_manifest=True,
)
```

The exporter refuses implicit overwrite, writes atomically, keeps vector DPI for embedded rasters, uses TIFF LZW, and can use PDF/PS Type 42 fonts. It does not validate scientific content or publisher acceptance.

For editable fonts:

- PDF/PS Type 42 embeds TrueType fonts.
- `svg.fonttype="none"` keeps text editable/searchable but does not embed fonts; appearance depends on installed fonts.
- `svg.fonttype="path"` preserves glyph appearance as paths but loses editable/searchable text.

Use an opaque explicit background unless transparency is required; blending against another background changes apparent contrast.

### 6. Inspect, compare, and review

1. Inspect file metadata.
2. Audit palette contrast/grayscale separation.
3. For publisher-targeted output, compare against applicable verified publisher requirements; snapshots are only a starting point.
4. View at final size in the manuscript/web context.
5. Manually review fonts, embedded rasters, clipping, legends, scale bars, image integrity, caption, alt text, and source data.
6. Re-check the live target-journal page when preparing an actual submission/upload, not on every exploratory revision.

## Runtime selection

Inspect the available Python runtime and versions only for packages needed by the chosen output. Prefer the existing environment when it supports the required APIs; record actual versions. Do not replace a working runtime or require Plotly/Kaleido for a Matplotlib figure. For exact replay, use the project lock or an isolated snapshot environment; do not mutate global packages. If a backend or Chrome is unavailable, use a suitable installed backend or provide an explicitly labeled export limitation. Never claim a snapshot was used unless it was actually executed. Verify official documentation before adopting changed APIs or updating pins; dated versions are not claims about the latest release.

For conceptual or qualitative figures, read `references/conceptual-figures.md`. Route precise box-and-arrow diagrams to native vector/code drawing tools; do not force them into statistical chart conventions.

## Pinned snapshot

The examples and smoke tests use direct package pins current on 2026-07-23:

```bash
uv run --isolated --no-project --python 3.13 \
  --with "matplotlib==3.11.1" \
  --with "seaborn==0.13.2" \
  --with "plotly==6.9.0" \
  --with "kaleido==1.3.0" \
  --with "pillow==12.3.0" \
  --with "pypdf==6.14.2" \
  python your_figure.py
```

This is a dated direct-dependency snapshot, not a transitive lock. Use the project's uv lock for exact replay; this skill intentionally ships no dependency lock.

## Bundled CLIs

All helpers are deterministic, network-free, bounded, reject symlink inputs/destinations where relevant, and refuse overwrite unless `--force` is explicit.

### Inspect raster/vector metadata

```bash
uv run --isolated --no-project --python 3.13 \
  --with "pillow==12.3.0" \
  python scripts/image_metadata.py figure.tiff \
  --format tiff --mode RGB --min-dpi 300 --target-width-mm 85 \
  --alpha-policy forbid
```

Supports raster images (Pillow), SVG, PDF (pypdf), and EPS/PS. Reports dimensions, DPI/effective DPI, mode, alpha, ICC presence, compression, page size, and conservative first-page PDF font resources. It does not inspect every embedded raster in a vector container.

### Audit palette contrast and grayscale

```bash
uv run --isolated --no-project --python 3.13 \
  python scripts/palette_audit.py \
  --palette okabe_ito_on_white \
  --background FFFFFF \
  --role graphical
```

Reports exact WCAG sRGB contrast plus pairwise CIE L* grayscale screening. The grayscale threshold is a heuristic, not a standard.

### Plan/screen publisher export

```bash
uv run --isolated --no-project --python 3.13 \
  python scripts/export_plan.py \
  --publisher nature \
  --figure-type combination \
  --width single \
  --phase final
```

Add `--input figure.pdf` to screen machine-readable properties. Profiles are official-source snapshots accessed 2026-07-23, not automatic compliance rules.

### Preview styles

```bash
uv run --isolated --no-project --python 3.13 \
  --with "matplotlib==3.11.1" \
  python scripts/style_preview.py \
  --output outputs/style-preview \
  --style default \
  --palette okabe_ito_on_white \
  --formats png,svg
```

### Inspect/write styles and smoke-test export

```bash
uv run --isolated --no-project --python 3.13 \
  python scripts/style_presets.py --list
uv run --isolated --no-project --python 3.13 \
  python scripts/style_presets.py --show nature
uv run --isolated --no-project --python 3.13 \
  --with "matplotlib==3.11.1" \
  python scripts/figure_export.py --demo outputs/export-smoke --manifest
```

## Assets

- `assets/publication.mplstyle`: general print starting point.
- `assets/nature.mplstyle`: dated flagship Nature visual starting point, not a compliance preset.
- `assets/presentation.mplstyle`: larger projected-display style.
- `assets/color_palettes.py`: importable Okabe-Ito and Paul Tol values with metadata.
- `assets/publisher_profiles.json`: dated, machine-readable planning snapshots.

Matplotlib style files omit `#` in hex colors because `#` begins comments in `.mplstyle` parsing.

## References

- `references/publication_guidelines.md`: integrity, deceptive encodings, accessibility, static/interactive output.
- `references/color_palettes.md`: palette semantics, exact values, WCAG contrast, grayscale caveats, color management.
- `references/journal_requirements.md`: phase-specific official publisher snapshots.
- `references/matplotlib_examples.md`: current, runnable Matplotlib/Seaborn/Plotly patterns.
- `references/sources.md`: official URLs, dates, versions, and research basis.

## Final review checklist

- [ ] Raw data/images and transformation code are preserved.
- [ ] Missing values, exclusions, bins, normalization, and uncertainty are explicit.
- [ ] Baselines, scales, limits, and area/volume encodings are honest.
- [ ] Color is redundant and rendered contrast was reviewed.
- [ ] Figure has an accessible description/data alternative where applicable.
- [ ] Physical dimensions, DPI, format, fonts, transparency, and file size were inspected after export.
- [ ] For journal-targeted delivery, publisher rules were verified for the exact journal and phase; for general/exploratory output, mark this check not applicable.
- [ ] No automated report is presented as a scientific, accessibility, or compliance certification.
